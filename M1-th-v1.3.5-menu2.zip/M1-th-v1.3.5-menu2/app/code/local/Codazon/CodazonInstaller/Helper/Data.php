<?php
class Codazon_CodazonInstaller_Helper_Data extends Mage_Core_Helper_Abstract
{
}
	 