<?php
class Codazon_Themeframework_Helper_Settings extends Mage_Core_Helper_Abstract
{
	public function prepareBodyClass()
	{
			
	}
}
	 